package com.place.order.service.impl;

import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.place.order.entity.OrderDetail;
import com.place.order.repo.OrderRepository;
import com.place.order.service.OrderService;

import reactor.core.publisher.Flux;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired(required = true)
	private OrderRepository orderRepository;

	@Override
	public void create(Flux<OrderDetail> orderList) {

		List<OrderDetail> orders = orderList.collectList().block();

		for (OrderDetail order : orders) {
			order.setOrderId(UUID.randomUUID().toString());
			order.setCustomerId(UUID.randomUUID().toString());
			order.setItemId(UUID.randomUUID().toString());
		}

		Flux<OrderDetail> sequence = Flux.fromIterable(orders);

		Flux<OrderDetail> saveAll = orderRepository.saveAll(sequence);

	}

}
