package com.place.order.repo;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;

import com.place.order.entity.OrderDetail;

@Repository
public interface OrderRepository extends ReactiveCrudRepository<OrderDetail, String> {

	

}
