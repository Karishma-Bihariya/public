package com.place.order.service;

import com.place.order.entity.OrderDetail;

import reactor.core.publisher.Flux;

public interface OrderService  {
    
	void create(Flux<OrderDetail> e);
}
